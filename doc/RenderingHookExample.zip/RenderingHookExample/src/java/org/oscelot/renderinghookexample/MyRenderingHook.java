package org.oscelot.renderinghookexample;

import java.util.Date;

/**
 *
 * @author Shane Argo <sargo@usc.edu.au>
 */
public class MyRenderingHook implements blackboard.servlet.renderinghook.RenderingHook {

    @Override
    public String getKey() {
        return "tag.learningSystemPage.start";
    }

    @Override
    public String getContent() {
        return String.format("<div>Rendering and what-not. <br/>(%s)</div>", new Date());
    }
    
}

