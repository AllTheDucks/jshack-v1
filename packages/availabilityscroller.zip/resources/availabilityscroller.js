Event.observe(window,"load", function() {
	setTimeout("scrollToStep3()", 600);
	
	var step3 = $('step3');
	var highlight = $('availabilityHighlight');
	step3.insert({ top: highlight });
});

function scrollToStep3() {
	Effect.ScrollTo('step3', { duration:'1.0', offset:-250 });
	setTimeout("displayHighlight()", 1000);
}
function displayHighlight() {
	Effect.Appear('availabilityHighlight', { duration: 1.5 });
}