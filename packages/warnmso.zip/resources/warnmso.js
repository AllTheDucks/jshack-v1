function scheduleSearch(editorName) {
	setTimeout('searchForMSO("' + editorName + '")',0);
}

function searchForMSO(editorName) {
	if(!stopWarning) {
		var html = editors[editorName].getHTML();
		
		if(MSOPattern.test(html)) {
			showMSOWarn();
			stopWarning = true;
		}
	}
}

function showMSOWarn() {
	$("msowarning-overlay").show();
	$("msowarning").show();
	centreMSOWarn();
}

function closeMSOWarn() {
	$("msowarning-overlay").hide();
	$('msowarning').hide();
}

function centreMSOWarn() {
	var elt  = $('msowarning');

	// retrieve required dimensions
	var eltDims  = elt.getDimensions();
	var browserDims = document.body.getDimensions();
	 
	// calculate the center of the page using the browser and element dimensions
	var y = (browserDims.height - eltDims.height) / 2;
	var x = (browserDims.width - eltDims.width) / 2;
	 
	// set the style of the element so it is centered
	var styles = { position : 'fixed',
		top : y + 'px',
		left : x + 'px' };
	 
	elt.setStyle(styles);
}


if(typeof HTMLArea != 'undefined') {

	var MSOPattern = /(class="Mso|<o:p)/i;
	var stopWarning = false;

	var originalInitIframe = HTMLArea.prototype.initIframe;
	HTMLArea.prototype.initIframe = function() {
		originalInitIframe.apply(this, arguments);
		scheduleSearch(this._name);
		var that = this;
		
		var onpaste = function(e){
			scheduleSearch(that._name);
			Event.stopObserving(that._iframe.contentDocument.body, "paste", onpaste);
			return true;
		}
		Event.observe(this._iframe.contentDocument.body, "paste", onpaste);
	};
	
	$('msowarning-close').observe('click', closeMSOWarn);

}