Event.observe(document, 'dom:loaded', function() {
	var permalinkWindow = $('permalink-window');
	var permalinkOverlay = $('permalink-overlay');
	var permalinkLink = $('permalink-link');
	
	var close = function() {
		permalinkWindow.hide();
		permalinkOverlay.hide();
	}
	
	var showPermalinkWindow = function () {
		var bottomURL = frames['content'].location.href;
			var parentOrigin = parent.location.origin || (parent.location.protocol + "//" + parent.location.hostname);
			if(bottomURL.substring(0,parentOrigin.length) == parentOrigin) {
				bottomURL = bottomURL.substring(parentOrigin.length);
			}
		var path = parentOrigin + '/webapps/portal/frameset.jsp?url=' + escape(bottomURL);
		var textbox = $('permalink-window-textbox');
		textbox.value = path;
		permalinkWindow.show();
		permalinkOverlay.show();
		textbox.activate();
	}
	
	$$(".global-nav-bar-wrap").first().insert(permalinkLink);
	permalinkLink.show();

	$('permalink-window-close').observe('click', close);
	$('permalink-window-done').observe('click', close);
	permalinkLink.observe('click', showPermalinkWindow);
});